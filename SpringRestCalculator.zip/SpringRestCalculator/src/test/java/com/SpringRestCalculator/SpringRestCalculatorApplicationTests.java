package com.SpringRestCalculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
