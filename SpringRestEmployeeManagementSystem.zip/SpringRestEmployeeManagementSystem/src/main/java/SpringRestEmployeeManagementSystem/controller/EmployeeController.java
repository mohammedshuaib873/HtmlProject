package SpringRestEmployeeManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import SpringRestEmployeeManagementSystem.model.Employee;
import SpringRestEmployeeManagementSystem.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeservice;
	
    @GetMapping("/")
    public List<Employee> getAll()
    {
    	return employeeservice.getAll();
    }
    
}
